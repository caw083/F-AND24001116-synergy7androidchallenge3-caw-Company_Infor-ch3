package com.example.challenge3_christopher_ade_wiyanto_

import java.io.Serializable

data class AlphabetData(val id: Int, val character: Char, val listWords: List<Word>) : Serializable