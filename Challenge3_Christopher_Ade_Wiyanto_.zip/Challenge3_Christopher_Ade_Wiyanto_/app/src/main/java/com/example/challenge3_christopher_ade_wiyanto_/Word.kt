package com.example.challenge3_christopher_ade_wiyanto_

import java.io.Serializable

data class Word(val id: Int, val words: String):Serializable